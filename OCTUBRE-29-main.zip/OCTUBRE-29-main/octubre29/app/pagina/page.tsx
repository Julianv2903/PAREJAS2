

export default function Algo() {
  return (
    <div className="algo">
      Algo
    </div>
  );
}
